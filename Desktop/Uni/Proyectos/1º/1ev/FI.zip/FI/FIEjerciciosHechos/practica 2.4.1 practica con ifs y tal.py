    #practica 2.4.1

##ejercicio 2
#
#a=int(raw_input("dame num"))
#b=int(raw_input("dame num"))
#c=int(raw_input("dame num"))
#if a>b>c:
#    print "estan en orden ascendente"
#else:
#    print"no estan en sentido ascendente"



##ejercicio 3
#
#a=int(raw_input("dame num"))
#b=int(raw_input("dame num"))
#c=int(raw_input("dame num"))
#d=int(raw_input("dame num"))
#e=int(raw_input("dame num"))
#if a>b and a>c and a>d and a>e:
#    print "el mayor es a"
#elif b>a and b>c and b>d and b>e:
#    print "el mayor es b"
#elif c>a and c>b and c>d and c>e:
#    print "el mayor es c"
#elif d>a and d>b and d>c and d>e:
#    print "el mayor es d"
#else:
#    print "el mayor es e"


##ejercicio 4
#
#a=float(raw_input("dame num"))
#b=float(raw_input("dame num"))
#x=-b/a
#print x


##ejercicio 5    ESTA MAL
#
#x=int(raw_input("dame num"))
#opcion=str(raw_input("dame una letra que sea a b o c"))
#if opcion== a or b or c
#    if opcion==a:
#        x^2
#    elif opcion==b:
#        x^3
#    elif opcion==c:
#        2*x
#    else:
#        print "opcion no correcta"

##ejercicio 6
#
#a=int(raw_input("dame num"))
#b=int(raw_input("dame num"))
#c=int(raw_input("dame num"))
#d=int(raw_input("dame num"))
#media=(a+b+c+d)/4
#if media<=100 and media>=90:
#    print "A"
#if media <90 and media >=80:
#    print "B"
#if media<80 and media >=70:
#    print "C"
#if media<70 and media >=60:
#    print "D"
#else:
#    print "E"

#ejercicio 7
#hay pila en internet ya hechos