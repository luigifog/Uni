###ejercicio1
##n=-1
##while n<0:
##    n=int(raw_input("numero >=0"))
##    a=n
##    for i in range(0,n,1):
##        n=n+i
##print "La suma de los primeros", a , "es" , n
###ejercicio2
##numero = int(input("escriba un numero entero mayor que cero: "))
##if numero <= 0:
##    print("le he pedido un numero entero mayor que cero")
##else:
##    factorial = 1
##    for i in range(1, numero + 1):
##        factorial = factorial * i
##    print( numero,"!=" , factorial)
###ejercicio3
##n=-1
##while n<0:
##    n=int(raw_input("numero >=0"))
##    for i in range(0,n+1,1):
##        n=i*"*"
##    print n
###ejercicio 4
##n=10
##for i in range(20,n-1,-1):
##    print i
###ejercicio 5
##n=20
##for i in range(40,n-1,-1):
##    print i
###ejercicio 6
##n=100
##for i in range(0,n+1,1):
##    if i%3==0:
##        print i
###ejercicio 7
##suma=0
##for i in range(1,101,1):
##    suma=(i**2+1.0)/i
##print suma
###ejercicio 8
##a=0
##b=int(raw_input("dame b"))
##suma=0
##while a<=0:
##    a=int(raw_input("dame a>0"))
##    for i in range(a,b+1,1):
##        suma=(i**2+1.0)/i
##print suma
###ejercicio 9
##a=int(raw_input("dame a"))
##b=int(raw_input("dame b"))
##for i in range(a,b+1,1):
##    if i%2==0:
##        print i, "par"
##    else:
##        print i, "impar"
###ejercicio 10
##a=-1
##while a<0:
##    a=int(raw_input("dame primer factor"))
##b=-1
##while b<0:
##    b=int(raw_input("dame segundo factor"))
##producto=0
##for i in range(0,b):
##    producto=producto+a
##print producto
###ejercicio 11
##n=0
##while n<=0:
##    n=int(raw_input("dame n>0"))
##    for i in range(1,n+1,1):
##        if n%i==0:
##             print  i,



