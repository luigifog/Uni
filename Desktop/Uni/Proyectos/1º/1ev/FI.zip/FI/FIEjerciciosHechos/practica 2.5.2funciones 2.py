#Parctica 2-5-2
#funciones
#ejercicio 2

##def divisores():
##    a=int(raw_input("dame numero"))
##    while a>0:
##        for i in range(a-1,0,-1):
##
##            if(a%i==0):
##                suma=0+i
##                print suma
##        break
##
##divisores()
##
##
##
##
#### print("perfecto")
####            else:
####                print("no perfecto")


###ejercicio 4
##ECHAR UN VISTAZO
##def es_primo():
##    a=  a=int(raw_input("dame numero"))
##    for i in range(a-1,1,-1):
##        if (a%a==0 and a%1==0 and a%i!=0):
##            print"verdadero"
##        else:
##            print"nein"
##es_primo()

#ejercicio 5

